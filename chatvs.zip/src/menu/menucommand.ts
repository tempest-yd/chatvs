import vscode from "vscode";
import { askAI } from "../openai/keycheck";
import { projects } from "../extension";

export async function addmenuscommand(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    
  );
};
