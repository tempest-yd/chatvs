import * as vscode from 'vscode';
import * as fs from 'fs';

export const remake = (context: vscode.ExtensionContext) => {
    let activeEditor = vscode.window.activeTextEditor;
    let decorationsArray: vscode.DecorationOptions[] = [];

    const decorationType = vscode.window.createTextEditorDecorationType({
        backgroundColor: 'rgba(255, 215, 0, 0.3)', // 金色背景，半透明
        borderRadius: '3px'
    });

    function removeDecorations() {
        if (activeEditor) {
            // 清除所有已应用的装饰
            for (let type in decorationTypes) {
                activeEditor.setDecorations(decorationTypes[type], []); // 移除对应类型的装饰
            }
        }
    }

    const decorationTypes: { [key: number]: vscode.TextEditorDecorationType } = {
        2: vscode.window.createTextEditorDecorationType({
            backgroundColor: 'rgba(255, 0, 0, 0.3)', // 红色背景，半透明
            borderRadius: '3px',
        }),
        4: vscode.window.createTextEditorDecorationType({
            backgroundColor: 'rgba(0, 255, 0, 0.3)', // 绿色背景，半透明
            borderRadius: '3px',
        }),
        3: vscode.window.createTextEditorDecorationType({
            backgroundColor: 'rgba(0, 0, 255, 0.3)', // 蓝色背景，半透明
            borderRadius: '3px',
        }),
        5: vscode.window.createTextEditorDecorationType({
            backgroundColor: 'rgba(128, 0, 128, 0.3)', // 紫色背景，半透明
            borderRadius: '3px',
        }),
    };

    const decorationRanges: { [key: number]: vscode.Range[] } = {
        2: [], // 红色
        3: [], // 绿色
        4: [], // 蓝色
        5: [], // 紫色
    };

    if (activeEditor) {
        removeDecorations();
        const document = activeEditor.document;
        initializeDecorations();
        loadAndApplyJsonDecorations(document);
    }

    vscode.window.onDidChangeActiveTextEditor(editor => {
        activeEditor = editor;
        if (editor) {
            const document = editor.document;
            initializeDecorations();
            loadAndApplyJsonDecorations(document);
        }
    }, null, context.subscriptions);

    vscode.workspace.onDidChangeTextDocument(event => {
        if (activeEditor && event.document === activeEditor.document) {
            updateDecorations(event.document, event.contentChanges);
        }
    }, null, context.subscriptions);

    function updateDecorations(document: vscode.TextDocument, changes: readonly vscode.TextDocumentContentChangeEvent[]) {
        if (activeEditor) {
            changes.forEach(change => {
                if (activeEditor) {
                    const startPos = activeEditor.document.positionAt(change.rangeOffset);
                    const endPos = activeEditor.document.positionAt(change.rangeOffset + change.rangeLength + change.text.length);
                    const decoration = { range: new vscode.Range(startPos, endPos), hoverMessage: "Newly edited content" };
                    decorationsArray.push(decoration);
                }
            });
            applyDecorations();
        }
    }

    function initializeDecorations() {
        removeDecorations();
        applyDecorations();
    }

    function applyDecorations() {
        if (activeEditor) {
            activeEditor.setDecorations(decorationType, decorationsArray);
        }
    }

    function loadAndApplyJsonDecorations(document: vscode.TextDocument) {
        if (!activeEditor) return;
        for (let key in decorationRanges) {
            decorationRanges[key] = [];
        }
        if (document.languageId === 'java' || document.languageId === 'plaintext') {
            const filePath = activeEditor.document.uri.fsPath;
            const jsonFilePath = filePath.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json');

            vscode.window.showInformationMessage(`你认为这个文件('${filePath}'）中的内容好还是不好？`, '好', '不好').then(selection => {
                if (selection) {
                    const result = selection === '好' ? '好' : '不好';
                    const logFilePath = filePath.replace(/\.java$/, '').replace(/\.txt$/, '') + '_review.txt';

                    fs.appendFile(logFilePath, `用户对文件 "${filePath}" 的评价是: ${result}\n`, (err) => {
                        if (err) {
                            vscode.window.showErrorMessage('Failed to save user feedback');
                            return;
                        }
                        vscode.window.showInformationMessage('评价已保存');
                    });
                }
            });

            if (fs.existsSync(jsonFilePath)) {
                fs.readFile(jsonFilePath, 'utf-8', (err, data) => {
                    if (err) {
                        vscode.window.showErrorMessage('Failed to read JSON file');
                        return;
                    }

                    try {
                        const jsonData = JSON.parse(data);
                        jsonData.forEach((item: { type: number, content: string }) => {
                            if (item.content.trim() === '') return;

                            const lineNum = findLineByContent(item.content);
                            if (lineNum !== -1 && activeEditor) {
                                const range = activeEditor.document.lineAt(lineNum).range;
                                if (item.type === 1) {
                                    const decoration = { range: range, hoverMessage: "Highlighted from JSON" };
                                    decorationsArray.push(decoration);
                                } else if (item.type >= 2 && item.type <= 5) {
                                    decorationRanges[item.type].push(range);
                                }
                            }
                        });
                        if (!activeEditor) {
                            vscode.window.showErrorMessage('No active editor');
                            return;
                        }
                        for (let type = 2; type <= 5; type++) {
                            if (decorationRanges[type].length > 0) {
                                activeEditor.setDecorations(decorationTypes[type], decorationRanges[type]);
                            }
                        }
                        applyDecorations();
                    } catch (parseError) {
                        vscode.window.showErrorMessage('Failed to parse JSON file');
                    }
                });
            }
        }
    }

    function findLineByContent(content: string): number {
        if (!activeEditor) return -1;
        const document = activeEditor.document;
        for (let i = 0; i < document.lineCount; i++) {
            const lineText = document.lineAt(i).text;
            if (lineText.includes(content)) {
                return i;
            }
        }
        return -1;
    }
};
