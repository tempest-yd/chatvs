import * as vscode from 'vscode';

import { getHtmlForWebview } from "../viewutil/webview";
import { askAI } from "../openai/keycheck"
import { text } from 'stream/consumers';
import { extractCodeAndText } from '../tools/re'
import { ex } from '../tools/ex'
import * as path from 'path';
import * as fs from 'fs-extra';
import { exec } from 'child_process';
import { projects } from '../extension';
import { creatfile } from "../tools/creatfile"
import * as JSON5 from 'json5';
// 创建一个 webview 视图
let webviewViewProvider: MyWebviewViewProvider | undefined;
// 获取扩展的根路径
// 遍历模块数组
interface Module {
  module: string;
  functionality: string[];
  pseudoCode: string;
}
//保存代码差别
interface Line {
  type: number;
  content: string;
}

interface CodeLine {
  type: number;
  content: string;
}

function removeExtension(filename: string, extension: string) {
  const regex = new RegExp(`${extension}$`);
  return filename.replace(regex, '');
}


function extractByTypeFromFile(filePath: string, typeValue: number): string {
  try {
    // 读取文件并解析为 JSON
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    const data: CodeLine[] = JSON.parse(fileContent);

    // 提取符合type条件的content，并且拼接为字符串
    return data
      .filter(item => item.type === typeValue && item.content.trim() !== "")
      .map(item => item.content)
      .join('');
  } catch (error) {
    console.error("Error reading or parsing file:", error);
    return '';
  }
}

function parseCodeToStructure(result: string, filename: string): CodeLine[] {
  const lines = result.split('\n'); // 按行分割
  const structuredArray: CodeLine[] = [];

  let currentType: number | null = null;

  for (let line of lines) {
    // 先去掉 undefined，再处理
    line = line.replace(/undefined/g, '').trim();
    if (line === '') {
      continue; // 跳过空行
    }
    const typeNumber = parseInt(line, 10);
    if (!isNaN(typeNumber)) {
      // 如果这一行是数字，表示这是一个 type 值
      currentType = typeNumber;
    } else if (currentType !== null) {
      // 如果当前行不是数字，则为代码内容
      const content = line.trim(); // 去掉前后的空白
      // 只有在 content 非空的情况下才添加到结果中
      if (content !== '') {
        structuredArray.push({
          type: currentType,
          content: content
        });
      }
    }
  }

  // 将 structuredArray 中的 content 保存为特定文件，type 全为 0(大模型生成)
  const outputArray = structuredArray.map(item => ({
    type: 0,
    content: item.content
  }));

  // 保存文件
  filename = filename.replace(/\.java$/, '') + '_java_human.json';
  const outputPath = path.resolve(__dirname, filename);
  fs.writeFileSync(outputPath, JSON.stringify(outputArray, null, 2), 'utf-8');

  return structuredArray; // 返回原始的 structuredArray
}


// 初始化 JSON 文件函数
async function initializeJsonFile(jsonFilePath: string, documentText: string) {
  return new Promise((resolve, reject) => {
    const lines = documentText.split('\n');
    const jsonData = lines.map(line => ({
      type: 0, // 初始类型为 0，表示没有颜色
      content: line
    }));

    fs.writeFile(jsonFilePath, JSON.stringify(jsonData, null, 2), { flag: 'wx' }, (err) => {
      if (err && err.code !== 'EEXIST') {
        reject(err);
      } else {
        resolve(true);
      }
    });
  });
}
// 实现 Webview 视图提供者接口，以下内容都是 chatGPT 提供
class MyWebviewViewProvider implements vscode.WebviewViewProvider {
  public webview?: vscode.WebviewView["webview"];

  constructor(private context: vscode.ExtensionContext) {
    this.context = context;
  }
  resolveWebviewView(webviewView: vscode.WebviewView): void {
    this.webview = webviewView.webview;
    // 设置 enableScripts 选项为 true
    webviewView.webview.options = {
      enableScripts: true,
      localResourceRoots: [vscode.Uri.file(path.join(this.context.extensionPath, 'html'))]
    };
    // 设置 Webview 的内容
    webviewView.webview.html = getHtmlForWebview(webviewView, this.context);



    //收消息
    webviewView.webview.onDidReceiveMessage(
      message => {
        const alarmManagementCode: string = `
        do for all sensors
            invoke checkSensor procedure returning signalValue
            if signalValue > bound[alarmType] then
                phone.message = message[alarmType]
                set alarmBell to "on" for alarmTimeSeconds
                set system status = "alarmCondition"
                
                parbegin
                    invoke alarm procedure with "on", alarmTimeSeconds
                    invoke phone procedure set for alarmType, phoneNumber
                parend
            else
                skip
            endif
        end do for
        end alarmManagement
        `;
        switch (message.command) {
          case 'updateproject':
            (async () => {

              const res = await askAI(message.con + "下面是你输出的具体要求：你回答的内容中所有冒号都采用英文冒号:，你回答的格式采用每个模块的格式严格按照###Module:Moudule name,@@@ablility:Moudule ability,&&&Pseudocode:```Pseudocode content```，回答内容都是用英文。下面是具体操作，你首先需要把这个项目分成模块，模块的具体的个数要根据需求的难易程度来衡量，项目越难分出的模块越多，项目越复杂分出的模块越少,无论你分成多少模块，他们组成的都应该是完整的项目。最终的结果以模块为单位返回，每个模块中包含模块名字(模块名字中不允许出现空格)，实现的功能（功能只需要文字叙述即可不超过10个字的简要描述）和伪代码（伪代码具体内容使用```包围" + `学习下面的伪代码的例子,然后按照我的需求生成对应的伪代码.example:${alarmManagementCode}` + "），在每个模块中的名字部分的开头加上'###'，每个模块中的功能部分的开头加上'@@@'，每个模块伪代码部分的开头加上'&&&'。", message.index);
              //const res = '### 模块名：游戏初始化@@@ 功能：初始化游戏棋盘和玩家信息&&& 伪代码：```function initializeGame():    创建一个空的五子棋棋盘    初始化玩家1和玩家2的名称    将当前回合设置为玩家1```### 模块名：绘制棋盘@@@ 功能：在控制台上绘制当前状态的五子棋棋盘&&& 伪代码：```function drawBoard(board):    for each 行 in board:        for each 列 in 行:            if 列有落子:                打印对应的落子颜色符号（如黑方格B，白方格W）            else:                打印未落子标记（如空方格.）        打印换行符```### 模块名：下棋逻辑  @@@ 功能：“人机对战”模式下实现人类玩家和AI完成自己所选位置出成功能，并判断胜利条件是否达成。&&& 伪代码：```function makeMove(player, row, col):    if (row, col) 不是有效位置或者已经被落子了：        返回无效移动            如果 player 不是当前回合玩家：        返回轮到其他玩家提示       在指定位置(row, col)处放置player的棋子       如果检查连续相同颜色的任意直线中存在五个以上连续相同颜色则结束游戏并宣布胜利者；      下一步将执行AI行动；          更新轮到下一个回合              ```### 模块名：主函数调用@@@ 功能: 调用上述模块组成完整游戏程序流程，让用户持续循环进行操作(输入行/列)&&& 伪代码：``` function main():     初始化游戏          while 游戏没有结束:         绘制当前状态的五子棋盘                 提示当前回合是哪位玩家（如果是AI，则显示AI正在思考...）                 接收用户输入选择                             如果输入选择为退出，则结束循环且宣布退出。                          否则，                              解析用户输入，得到需要放置的位置                                     根据解析结果调用“下棋逻辑”模块来进行处理                     游戏结束时打印最后结果  main()```undefined'
              const segments: Module[] = extractCodeAndText(res);

              const model = vscode.workspace.getConfiguration('ai').get('path') + ""


              let project = projects.find(project => project.id === message.index);

              if (project) {
                const basePath = path.join(model, project.name.replace(/:/g, '-'));
                project.segments = [];
                segments.forEach(segment => {

                  project.segments.push({ name: segment.module, id: new Date().toISOString() })
                  const fileName = `${segment.module}.txt`;
                  const filePath = path.join(basePath, fileName);
                  const content = segment.pseudoCode;
                  const language = vscode.workspace.getConfiguration('ai').get('language') + "";
                  const fileExtension: string = getFileExtension(language);
                  const filePath1 = path.join(basePath, segment.module + fileExtension);
                  const content1 = `还未生成${language}代码`;
                  try {
                    // 创建文件并写入内容
                    fs.writeFileSync(filePath, content);
                    fs.writeFileSync(filePath1, content1);
                    console.log(`文件 "${fileName}" 已创建并写入内容。`);
                  } catch (error) {
                    console.error(`创建文件 "${fileName}" 时出错: ` + error);
                  }

                });
                webviewView.webview.postMessage({ command: 'reupdateproject', segments: project.segments, ability: segments });
              }

              // 继续执行其他逻辑
            })();
            return;
          case 'makeproject':
            (async () => {
              const model = vscode.workspace.getConfiguration('ai').get('path') + ""
              const patha = path.join(model, message.project.replace(/:/g, '-'));
              if (!fs.existsSync(patha)) {
                fs.mkdirSync(patha, { recursive: true });
              }
              projects.push({ id: message.project, name: message.project, segments: [] })
            })();
            webviewView.webview.postMessage({});
            return;
          case 'renameproject':
            (async () => {
              if (message.raw == message.name) {
                webviewView.webview.postMessage({ command: 'renamea', success: 0, index: message.index })
                return;
              }
              // 要重命名的文件路径
              const oldFileName = message.raw.replace(/:/g, '-');
              const newFileName = message.name;
              const model = vscode.workspace.getConfiguration('ai').get('path') + ""
              // 获取文件的完整路径
              const oldFilePath = path.join(model, oldFileName);
              const newFilePath = path.join(model, newFileName);
              fs.access(newFilePath, fs.constants.F_OK, (err) => {
                if (!err) {
                  // 文件或文件夹已存在
                  vscode.window.showErrorMessage(`模块名${newFileName}重复`);
                  webviewView.webview.postMessage({ command: 'renamea', success: 0, index: message.index });
                } else {
                  // 使用 fs 模块重命名文件
                  fs.rename(oldFilePath, newFilePath, (erra) => {
                    if (erra) {
                      console.log(erra)
                      vscode.window.showErrorMessage("项目名不符合规范")
                      webviewView.webview.postMessage({ command: 'renamea', success: 0, index: message.index });
                    } else {
                      let project = projects.find(project => project.id === message.id);
                      if (project) {
                        project.name = newFileName
                      }
                      webviewView.webview.postMessage({ command: 'renamea', success: 1, index: message.index });
                    }
                  });
                }
              })
            })();
            webviewView.webview.postMessage({});
            return;
          case 'makefile':
            (async () => {
              const res = await askAI(message.con + "根据我上面的功能生成伪代码，让我能把最后的伪代码直接写进txt里面，不要返回多余文字", message.id);
              // 生成唯一的时间戳
              const model = vscode.workspace.getConfiguration('ai').get('path') + ""
              const time1 = message.projectname.replace(/:/g, '-');
              const time2 = message.indexname.replace(/:/g, '-');
              const fileName = `pseudocode_${time2}.txt`;
              const filePath = path.join(model, time1, fileName);

              // 创建文件并写入内容
              fs.writeFileSync(filePath, res);
              // 在 VS Code 中打开文件
              vscode.workspace.openTextDocument(filePath).then(doc => {
                vscode.window.showTextDocument(doc);
              }, err => {
                vscode.window.showErrorMessage(`打开文件时出错: ${err.message}`);
              });
            })();
            webviewView.webview.postMessage({});
            return;
          case 'addmodel':
            (async () => {
              let project = projects.find(project => project.id === message.project);
              if (project) {
                project.segments.push({ id: message.index, name: message.index })
              }
              //定义语言变量
              const language = vscode.workspace.getConfiguration('ai').get('language') + "";  // 可以设置为 'java', 'python', 'javascript', 等等
              const model = vscode.workspace.getConfiguration('ai').get('path') + ""

              //文件内容
              const fileContent: string = `// This is a sample ${language} file`;
              //文件路径
              const fileExtension: string = getFileExtension(language);
              const fileName1: string = message.index + `${fileExtension}`;
              const fileName: string = message.index + '.txt';

              if (project) {
                const filePath1: string = path.join(model, project.name.replace(/:/g, '-'), fileName1.replace(/:/g, '-'));
                const filePath: string = path.join(model, project.name.replace(/:/g, '-'), fileName.replace(/:/g, '-'));
                // 创建并写入文件
                try {
                  // 创建文件并写入内容
                  fs.writeFileSync(filePath, "123");
                  fs.writeFileSync(filePath1, "这是一个空的伪代码文件等待生成");
                } catch (error) {
                  console.error(`创建文件 "${fileName}" 时出错: ` + error);
                }
              }
            })();
            webviewView.webview.postMessage({});
            return;
          case 'renamemodel':
            (async () => {
              let project = projects.find(project => project.id === message.proid);
              if (message.raw == message.name) {
                webviewView.webview.postMessage({ command: 'renamemodel', success: 0, index: message.index })
                return;
              }
              // 要重命名的文件路径
              if (project) {
                const time1 = project.name.replace(/:/g, '-');

                const oldFileName = message.raw.replace(/:/g, '-');
                const newFileName = message.name;
                const model = vscode.workspace.getConfiguration('ai').get('path') + ""

                //定义语言变量
                const language = vscode.workspace.getConfiguration('ai').get('language') + "";  // 可以设置为 'java', 'python', 'javascript', 等等
                //文件路径
                const fileExtension: string = getFileExtension(language);
                const fileName1: string = oldFileName + `${fileExtension}`;
                const fileName2: string = newFileName + `${fileExtension}`;
                // 获取文件的完整路径
                const oldFilePath = path.join(model, time1, fileName1);
                const newFilePath = path.join(model, time1, fileName2);
                // 使用 fs 模块重命名文件
                fs.access(newFilePath, fs.constants.F_OK, (err) => {
                  if (!err) {
                    // 文件或文件夹已存在
                    vscode.window.showErrorMessage(`模块名${newFileName}重复`);
                    webviewView.webview.postMessage({ command: 'renamemodel', success: 0, index: message.index });
                  } else {
                    fs.rename(oldFilePath, newFilePath, (erra) => {
                      if (erra) {
                        console.log(erra)
                        vscode.window.showErrorMessage(`模块名${newFileName}不符合规范`)
                        webviewView.webview.postMessage({ command: 'renamemodel', success: 0, index: message.index });
                        return;
                      } else {
                        let pro = project.segments.find(pro => pro.id === message.id);
                        if (pro) {
                          pro.name = newFileName
                        }
                        webviewView.webview.postMessage({ command: 'renamemodel', success: 1, index: message.index });
                      }
                    });
                  }
                })

                //文件路径
                const fileName3: string = oldFileName + '.txt';
                const fileName4: string = newFileName + '.txt';
                // 获取文件的完整路径
                const oldFilePath1 = path.join(model, time1, fileName3);
                const newFilePath1 = path.join(model, time1, fileName4);
                // 使用 fs 模块重命名文件
                fs.access(newFilePath1, fs.constants.F_OK, (err) => {
                  if (!err) {
                    // 文件或文件夹已存在
                    vscode.window.showErrorMessage(`模块名${newFileName}重复`);
                    webviewView.webview.postMessage({ command: 'renamemodel', success: 0, index: message.index });
                  } else {
                    fs.rename(oldFilePath1, newFilePath1, (erra) => {
                      if (erra) {
                        console.log(erra)
                        vscode.window.showErrorMessage(`模块名${newFileName}不符合规范`)
                        webviewView.webview.postMessage({ command: 'renamemodel', success: 0, index: message.index });
                        return;
                      } else {
                        let pro = project.segments.find(pro => pro.id === message.id);
                        if (pro) {
                          pro.name = newFileName
                        }
                        webviewView.webview.postMessage({ command: 'renamemodel', success: 1, index: message.index });
                      }
                    });
                  }
                })
              }
            })();
            return;
          case 'openfile':
            (async () => {
              if (message.num == 1) {
                // 打开伪代码
                const model = vscode.workspace.getConfiguration('ai').get('path') + ""
                const time1 = message.projectname.replace(/:/g, '-');
                const time2 = message.indexname.replace(/:/g, '-');
                const fileName = `${time2}.txt`;
                const filePath = path.join(model, time1, fileName);
                const fileContent = '还未生成伪代码';
                try {
                  await fs.promises.access(filePath);
                  console.log('File exists, opening...');
                  // 打开文件
                  vscode.workspace.openTextDocument(filePath).then(doc => {
                    vscode.window.showTextDocument(doc);
                  }, err => {
                    vscode.window.showErrorMessage(`打开文件时出错: ${err.message}`);
                  });
                } catch (error) {
                  console.log('File does not exist, creating...');
                  try {
                    await fs.promises.writeFile(filePath, fileContent);
                    console.log('File created successfully');
                    await fs.promises.access(filePath);
                    console.log('File exists, opening...');
                    // 打开文件
                    vscode.workspace.openTextDocument(filePath).then(doc => {
                      vscode.window.showTextDocument(doc);
                    }, err => {
                      vscode.window.showErrorMessage(`打开文件时出错: ${err.message}`);
                    });
                  } catch (error) {
                    console.error('Error creating file:', error);
                  }
                }
              } else {
                // 打开代码
                const model = vscode.workspace.getConfiguration('ai').get('path') + ""
                const time1 = message.projectname.replace(/:/g, '-');
                const time2 = message.indexname.replace(/:/g, '-');
                const language = vscode.workspace.getConfiguration('ai').get('language') + "";
                const fileExtension: string = getFileExtension(language);
                const fileName: string = time2 + `${fileExtension}`;
                const filePath = path.join(model, time1, fileName);
                const fileContent = '还未生成代码';
                try {
                  await fs.promises.access(filePath);
                  console.log('File exists, opening...');
                  // 打开文件
                  vscode.workspace.openTextDocument(filePath).then(doc => {
                    vscode.window.showTextDocument(doc);
                  }, err => {
                    vscode.window.showErrorMessage(`打开文件时出错: ${err.message}`);
                  });
                } catch (error) {
                  console.log('File does not exist, creating...');
                  try {
                    await fs.promises.writeFile(filePath, fileContent);
                    console.log('File created successfully');
                    await fs.promises.access(filePath);
                    console.log('File exists, opening...');
                    // 打开文件
                    vscode.workspace.openTextDocument(filePath).then(doc => {
                      vscode.window.showTextDocument(doc);
                    }, err => {
                      vscode.window.showErrorMessage(`打开文件时出错: ${err.message}`);
                    });
                  } catch (error) {
                    console.error('Error creating file:', error);
                  }
                }
              }
            })();
            webviewView.webview.postMessage({});
            return;
          case "deletemodel":
            (async () => {
              const time1 = message.proname.replace(/:/g, '-');
              const FileName = message.modelname.replace(/:/g, '-');;
              const model = vscode.workspace.getConfiguration('ai').get('path') + ""

              //定义语言变量
              const language = vscode.workspace.getConfiguration('ai').get('language') + "";  // 可以设置为 'java', 'python', 'javascript', 等等
              //根据语言类型决定文件扩展名
              const getFileExtension = (language: string): string => {
                switch (language.toLowerCase()) {
                  case 'java':
                    return '.java';
                  case 'python':
                    return '.py';
                  case 'javascript':
                    return '.js';
                  case 'typescript':
                    return '.ts';
                  // 添加其他语言及其文件扩展名
                  default:
                    throw new Error('Unsupported language type');
                }
              };
              //文件路径
              const fileExtension: string = getFileExtension(language);
              const fileName1: string = FileName + `${fileExtension}`;
              const fileName2: string = FileName + '.txt';
              // 获取文件的完整路径
              const FilePath1 = path.join(model, time1, fileName1);
              // 获取文件的完整路径
              const FilePath2 = path.join(model, time1, fileName2);
              await fs.remove(FilePath1);
              await fs.remove(FilePath2);
            })();
            webviewView.webview.postMessage({});

          case 'addproject':
            (async () => {
              const model = vscode.workspace.getConfiguration('ai').get('propath') + ""
              const result: Module[] = [];
              const a: { con: string; name: string }[] = [];
              const language = vscode.workspace.getConfiguration('ai').get('language') + "";
              const fileExtension: string = getFileExtension(language);
              // 读取目录中的所有文件
              fs.readdirSync(model).forEach(file => {
                const filePath = path.join(model, file);

                // 检查是否为文件
                if (fs.statSync(filePath).isFile() && file.endsWith(fileExtension)) {
                  // 读取文件内容
                  const content = fs.readFileSync(filePath, 'utf-8');
                  a.push({ con: content, name: file });
                }
              });
              const mod = vscode.workspace.getConfiguration('ai').get('path') + ""
              const patha = path.join(mod, message.index.replace(/:/g, '-'));
              if (!fs.existsSync(patha)) {
                fs.mkdirSync(patha, { recursive: true });
              }
              for (const se of a) {
                const res = await askAI(se.con + "下面是你输出的具体要求：你回答的内容中所有冒号都采用英文冒号:，你回答的格式采用每个模块的格式严格按照###Module:Moudule name,@@@ablility:Moudule ability,&&&Pseudocode:```Pseudocode content```，回答内容都是用英文。下面是具体操作，你首先需要理解这个代码，然后，给这段代码起一个文件名(名字中不允许出现空格)，说明它实现的功能（功能只需要文字叙述即可不超过10个字的简要描述）和这段代码对应的伪代码（伪代码具体内容使用```包围" + `学习下面的伪代码的例子,然后按照我的需求生成对应的伪代码.example:${alarmManagementCode}` + "），在名字部分的开头加上'###'，功能部分的开头加上'@@@'，伪代码部分的开头加上'&&&'。", message.index);
                let segments: Module = extractCodeAndText(res)[0];

                const re = removeExtension(se.name, fileExtension); // result: "example"
                segments.module = re
                result.push(segments)

              }
              projects.push({ id: message.index, name: message.index, segments: [] })
              //const res = '### 模块名：游戏初始化@@@ 功能：初始化游戏棋盘和玩家信息&&& 伪代码：```function initializeGame():    创建一个空的五子棋棋盘    初始化玩家1和玩家2的名称    将当前回合设置为玩家1```### 模块名：绘制棋盘@@@ 功能：在控制台上绘制当前状态的五子棋棋盘&&& 伪代码：```function drawBoard(board):    for each 行 in board:        for each 列 in 行:            if 列有落子:                打印对应的落子颜色符号（如黑方格B，白方格W）            else:                打印未落子标记（如空方格.）        打印换行符```### 模块名：下棋逻辑  @@@ 功能：“人机对战”模式下实现人类玩家和AI完成自己所选位置出成功能，并判断胜利条件是否达成。&&& 伪代码：```function makeMove(player, row, col):    if (row, col) 不是有效位置或者已经被落子了：        返回无效移动            如果 player 不是当前回合玩家：        返回轮到其他玩家提示       在指定位置(row, col)处放置player的棋子       如果检查连续相同颜色的任意直线中存在五个以上连续相同颜色则结束游戏并宣布胜利者；      下一步将执行AI行动；          更新轮到下一个回合              ```### 模块名：主函数调用@@@ 功能: 调用上述模块组成完整游戏程序流程，让用户持续循环进行操作(输入行/列)&&& 伪代码：``` function main():     初始化游戏          while 游戏没有结束:         绘制当前状态的五子棋盘                 提示当前回合是哪位玩家（如果是AI，则显示AI正在思考...）                 接收用户输入选择                             如果输入选择为退出，则结束循环且宣布退出。                          否则，                              解析用户输入，得到需要放置的位置                                     根据解析结果调用“下棋逻辑”模块来进行处理                     游戏结束时打印最后结果  main()```undefined'
              let project = projects.find(project => project.id === message.index);

              if (project) {
                const basePath = path.join(mod, project.name.replace(/:/g, '-'));
                project.segments = [];
                result.forEach((segment, index) => {

                  project.segments.push({ name: segment.module, id: new Date().toISOString() })
                  const fileName = `${segment.module}.txt`;
                  const filePath = path.join(basePath, fileName);
                  const content = segment.pseudoCode;
                  const language = vscode.workspace.getConfiguration('ai').get('language') + "";
                  const fileExtension: string = getFileExtension(language);
                  const filePath1 = path.join(basePath, segment.module + fileExtension);
                  const content1 = `${a[index].con}`;
                  try {
                    // 创建文件并写入内容
                    fs.writeFileSync(filePath, content);
                    fs.writeFileSync(filePath1, content1);
                    console.log(`文件 "${fileName}" 已创建并写入内容。`);
                  } catch (error) {
                    console.error(`创建文件 "${fileName}" 时出错: ` + error);
                  }

                });
                webviewView.webview.postMessage({ command: 'addproject', segments: project.segments, ability: result, id: message.index });
              }
            })();
        }
      },
      undefined,
      this.context.subscriptions
    );
  }
  disable() {
    if (this.webview) {
      this.webview.postMessage({ command: "dis" });
    }
  }
  able() {
    if (this.webview) {
      this.webview.postMessage({});
    }
  }
  addabilities(message: { project: string, model: string, con: string }) {
    if (this.webview) {
      this.webview.postMessage({ command: 'addabilities', project: message.project, model: message.model, con: message.con });
    }
  }
  // 销毁
  removeWebView() {
    this.webview = undefined;
  }

}

/**
 * 删除指定文件夹及其内容
 * @param dirPath 文件夹路径
 */
//根据语言类型决定文件扩展名
const getFileExtension = (language: string): string => {
  switch (language.toLowerCase()) {
    case 'java':
      return '.java';
    case 'python':
      return '.py';
    case 'javascript':
      return '.js';
    case 'typescript':
      return '.ts';
    case 'c++':
      return '.cpp'
    case 'html':
      return '.html'
    default:
      throw new Error('Unsupported language type');
  }
};
const openChatGPTView = (selectedText?: string) => {
  // 唤醒 chatGPT 视图 连接openai此处写后端
  vscode.commands.executeCommand("workbench.view.extension.CodeToolBox").then(() => {
    vscode.commands
      .executeCommand("setContext", "CodeToolBox.chatGPTView", true)
      .then(() => {
        //验证获取设置中的内容，在package。json中的configuration中设置
        const config = vscode.workspace.getConfiguration("CodeToolBox");
        const hostname = config.get("hostname");
        const apiKey = config.get("apiKey");
        const model = config.get("model");
        setTimeout(() => {
          // 发送任务,并传递参数
          if (!webviewViewProvider || !webviewViewProvider?.webview) {
            return;
          }
          webviewViewProvider.webview.postMessage({
            cmd: "vscodePushTask",
            task: "route",
            data: {
              path: "/chat-gpt-view",
              query: {
                hostname,
                apiKey,
                selectedText,
                model,
              },
            },
          });
        }, 500);
      });
  });
};
export async function createwebview(context: vscode.ExtensionContext) {
  // 注册 webview 视图
  //此方法链接json中的views，type为webview类型
  webviewViewProvider = new MyWebviewViewProvider(context);
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(
      "CodeToolBox.chatGPTView",
      webviewViewProvider,
      {
        webviewOptions: {
          retainContextWhenHidden: true,
        },
      },
    ),
  );

  context.subscriptions.push(
    // 添加打开视图
    vscode.commands.registerCommand("CodeToolBox.openChatGPTView", () => {
      openChatGPTView();
    }),

    // 添加关闭视图
    vscode.commands.registerCommand("CodeToolBox.hideChatGPTView", () => {
      vscode.commands
        .executeCommand("setContext", "CodeToolBox.chatGPTView", false)
        .then(() => {
          webviewViewProvider?.removeWebView();
        });
    }),
    vscode.commands.registerCommand('CodeToolBox.abilities', () => {
      (async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No active editor!');
          return;
        }
        const document = editor.document;
        const content = document.getText();

        //const result = "yes"
        const fileName = document.fileName;
        const fileType = fileName.substring(fileName.lastIndexOf('\\') + 1);
        const filename = fileType.substring(0, fileType.lastIndexOf('.'));
        let project = projects.find(project => (project.segments.find(segment => segment.name.replace(/:/g, '-') === filename)));

        if (project) {
          let model = project?.segments.find(segment => segment.name.replace(/:/g, '-') === filename)
          const result: string = await askAI(content + "请根据上面的代码或者伪代码，生成他们顺序实现了哪些功能，每个功能标为一行，要求简要概括。最终的结果只有分行陈述的功能不要包含其他信息", project.id)
          if (model) {
            webviewViewProvider?.addabilities({ project: project?.id, model: model.id, con: result });
          }
        }
      })();

    }),
    vscode.commands.registerCommand('CodeToolBox.pseudocode', () => {
      (async () => {
        webviewViewProvider?.disable()
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No active editor!');
          webviewViewProvider?.able()
          return;
        }
        const document = editor.document;
        const content = document.getText();


        const fileName = document.fileName;
        const filename = fileName.substring(0, fileName.lastIndexOf('.')) + ".txt";

        const fileType1 = fileName.substring(fileName.lastIndexOf('\\') + 1);
        const filename1 = fileType1.substring(0, fileType1.lastIndexOf('.'));
        let project = projects.find(project => (project.segments.find(segment => segment.name.replace(/:/g, '-') === filename1)));
        let res = "";
        if (project) {
          res = await askAI(content + "请根据上面的代码，生成他们的伪代码。最终的结果只有伪代码不要包含其他信息，伪代码采用自然语言不要使用代码语言！！", project.id)
        }
        try {
          // 创建文件并写入内容
          fs.writeFileSync(filename, ex(res).content);
          console.log(`文件 "${fileName}" 已创建并写入内容。`);
          webviewViewProvider?.able()
        } catch (error) {
          console.error(`创建文件 "${fileName}" 时出错: ` + error);
          webviewViewProvider?.able()
        }
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.code', () => {
      (async () => {
        webviewViewProvider?.disable();
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No active editor!');
          webviewViewProvider?.able();
          return;
        }
        const document = editor.document;
        const content = document.getText();
        const language = vscode.workspace.getConfiguration('ai').get('language') + "";
        const fileExtension: string = getFileExtension(language);
        const fileName = document.fileName;
        const fileType1 = fileName.substring(fileName.lastIndexOf('\\') + 1);
        const filename1 = fileType1.substring(0, fileType1.lastIndexOf('.'));
        let project = projects.find(project => (project.segments.find(segment => segment.name.replace(/:/g, '-') === filename1)));
        let result = "";
        let res = "";
        let currentCode = "";
        let project_id = '';
        // 文件路径
        const filename = fileName.substring(0, fileName.lastIndexOf('.')) + `${fileExtension}`;
        if (fs.existsSync(filename)) {
          currentCode = fs.readFileSync(filename, 'utf8');
          if (currentCode === "还未生成java代码") { currentCode = ""; }
          console.log(`File ${filename} exists. Reading currentCode from ${filename}，${currentCode}`)
        } else {
          console.log(`File ${filename} does not exist. Proceeding without current code "${filename}".`);
        }
        const codeTypeFile = fileName.substring(0, fileName.lastIndexOf('.')) + '_txt.json';
        let codeType = "";
        if (fs.existsSync(codeTypeFile)) {
          codeType = fs.readFileSync(codeTypeFile, 'utf8');
          console.log(`File ${codeTypeFile} exists. Reading currentCode from ${codeTypeFile}`);
        }
        if (project) {
          project_id = project.id;
          console.log("content" + content);
          result = await askAI(content + `上面的内容是你之前帮我生成一个模块中的伪代码，结合整个项目的需求，完成这些伪代码为一个类。注意，你只需要生成该模块的代码，不需要考虑其他模块，并请根据上面的伪代码，生成他的${fileExtension}代码。不用给我代码
                  此外，这是我的伪代码样式结构体：${codeType}。若为空，请忽略。请在生成代码后，过滤掉空行，以代码行为单位，给出代码和对应的type信息。示例如下：
                  1（应为number，对应:currentCode中，产生该代码的伪代码对应的type值。每行代码都需要对应某一行伪代码，可以多行代码对应一行伪代码。）
                  import os;（对应本行代码的内容）
                  你只需给出代码和对应的type信息，不要出现任何其他内容，包括注释。`, project.id);
          let structuredResult: CodeLine[] = [];
          try {
            let structured = parseCodeToStructure(result, filename);
            structuredResult = structured;
          }
          catch (error) {
            console.error(`转换为json格式时出错: ` + error);
          }
          try {
            fs.writeFileSync(filename.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json'), JSON.stringify(structuredResult, null, 2), 'utf-8');
            console.log(`json文件已创建并写入内容。`);
            webviewViewProvider?.able();
          }
          catch (error) {
            console.error(`创建json文件时出错: ` + error);
            webviewViewProvider?.able();
            structuredResult = [];
          }
          if (structuredResult.length > 0) {
            res = structuredResult
              .filter((item: { content: string }) => item.content.trim() !== '') // 过滤掉空的 content
              .map((item: { content: string }) => item.content) // 提取 content
              .join('\n'); // 用 \n 连接每行内容
            try {
              fs.writeFileSync(filename, res);
              console.log(`文件 "${filename}" 已创建并写入内容。`);
              webviewViewProvider?.able();
            } catch (error) {
              console.error(`创建文件"${filename}"时出错: ` + error);
              webviewViewProvider?.able();
            }
          }
        }
        // 对比新旧代码并高亮显示
        if (currentCode.length > 0) {
          let comparisonResult = "";
          comparisonResult = await askAI(
            `下面是当前的代码与新生成的代码，请以行为单位，进行对比，并以结构体数组的方式给出新生成的代码及其高亮状态。你只需返回新生成的代码，改动的部分需要用高亮标记：
                    [
                        {
                            "type": "1" or "0"，其中1表示需要高亮，0表示不需要高亮,
                            "content": "",对应本行代码的内容
                        }
                    ]
                    至于其他原有代码，若有type，赋值为先前的type
                    当前代码：${currentCode}
                    新生成的代码：${res}
                    请确保 JSON 的格式如下：
                      键和值：使用双引号 "，且键和值都应该正确匹配
                      标准的符号使用：避免全角符号，使用标准的英文标点符号（如 : 和 ,）。
                      不要添加任何多余内容，包括注释`, project_id
          );
          const baseFileName = fileName.substring(0, fileName.lastIndexOf('.'));
          const modifiedFileExtension = fileExtension.replace('.', '_');
          const comparisonResultFilename = baseFileName + `${modifiedFileExtension}.json`;
          try {
            fs.writeFileSync(filename, ex(res).content); // 保存代码文件
            console.log(`文件 "${filename}" 已创建并写入内容。`);
            webviewViewProvider?.able();
          } catch (error) {
            console.error(`创建文件 "${filename}" 时出错: ` + error);
            webviewViewProvider?.able();
          }
          console.log("comparisonResult:" + ex(comparisonResult).content);
          try {
            fs.writeFileSync(comparisonResultFilename, ex(comparisonResult).content, 'utf8'); // 保存结构体信息
            console.log(`文件"${comparisonResultFilename}" 已创建并写入内容。`);
            webviewViewProvider?.able();
          } catch (error) {
            console.error(`创建文件 "${comparisonResultFilename}" 时出错: ` + error);
            webviewViewProvider?.able();
          }
        }
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.mergeall', () => {
      (async () => {
        webviewViewProvider?.disable()
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No active editor!');
          webviewViewProvider?.able()
          return;
        }
        const document = editor.document;
        const content = document.getText();
        const language = vscode.workspace.getConfiguration('ai').get('language') + "";
        const fileExtension: string = getFileExtension(language);

        const fileName = document.fileName;

        const fileType1 = fileName.substring(fileName.lastIndexOf('\\') + 1);
        const filename1 = fileType1.substring(0, fileType1.lastIndexOf('.'));
        let project = projects.find(project => (project.segments.find(segment => segment.name.replace(/:/g, '-') === filename1)));
        let res = "";
        //文件路径
        const filename = fileName.substring(0, fileName.lastIndexOf('.')) + `${fileExtension}`;
        if (project) {
          res = await askAI(content + `上面的内容是你之前帮我生成一个模块中的伪代码，我想把他作为主模块，请根据你刚刚⽣成的各个模块的接⼝，为主游戏模块⽣成${fileExtension}代码,并请根据上面的伪代码，生成他的${fileExtension}代码。最终的结果只有代码不要包含其他信息，我要把它写入到名字为${filename}的文件中,注意代码中要包含main函数作为整个项目的入口，然后你只需要⽣成该模块的代码，不需要考虑其他模块。`, project.id)
        }

        try {
          // 创建文件并写入内容
          fs.writeFileSync(filename, ex(res).content);
          console.log(`文件 "${filename}" 已创建并写入内容。`);
          webviewViewProvider?.able()
        } catch (error) {
          console.error(`创建文件 "${filename}" 时出错: ` + error);
          webviewViewProvider?.able()
        }
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.changeColorRed', async () => {
      await (async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No editor is active');
          return;
        }

        const selection = editor.selection;
        if (selection.isEmpty) {
          vscode.window.showInformationMessage('No text selected');
          return;
        }

        // 获取当前文件路径
        const filePath = editor.document.uri.fsPath;
        const jsonFilePath = filePath.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json');

        // 读取当前文件的内容
        const documentText = editor.document.getText();

        // 检查并初始化 JSON 文件
        if (!fs.existsSync(jsonFilePath)) {
          await initializeJsonFile(jsonFilePath, documentText);
        }
        const lines = documentText.split('\n');
        // Define a decoration type with red color and transparency
        const decorationType = vscode.window.createTextEditorDecorationType({
          backgroundColor: 'rgba(255, 0, 0, 0.3)',
        });

        // Apply the decoration to the selected text
        editor.setDecorations(decorationType, [selection]);

        // 获取选中区域的起始和结束行
        const startLine = selection.start.line;
        const endLine = selection.end.line;

        // 读取现有的 JSON 数据
        let jsonData = [];
        const jsonContent = fs.readFileSync(jsonFilePath, 'utf-8');
        jsonData = JSON.parse(jsonContent);

        // 创建要装饰的范围数组
        const rangesToDecorate = [];

        // 遍历选中的每一行
        for (let lineNumber = startLine; lineNumber <= endLine; lineNumber++) {
          const selectedLineContent = lines[lineNumber];

          // 查找当前行在 JSON 中是否已经存在
          const lineEntry = jsonData.find((entry: any) => entry.content === selectedLineContent);

          if (lineEntry) {
            // 如果行已经存在，更新其类型为红色
            lineEntry.type = 2;
          } else {
            // 如果行不存在，添加一个新的记录
            jsonData.push({
              type: 2, // 红色
              content: selectedLineContent,
            });
          }

          // 为选定行创建范围
          const range = new vscode.Range(lineNumber, 0, lineNumber, lines[lineNumber].length);
          rangesToDecorate.push(range);
        }

        // 将更新后的 JSON 数据写回文件
        fs.writeFileSync(jsonFilePath, JSON.stringify(jsonData, null, 2), 'utf-8');
        vscode.window.showInformationMessage('Style changes saved to JSON file successfully!');
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.changeColorBlue', async () => {
      await (async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No editor is active');
          return;
        }

        const selection = editor.selection;
        if (selection.isEmpty) {
          vscode.window.showInformationMessage('No text selected');
          return;
        }
        // 获取当前文件路径
        const filePath = editor.document.uri.fsPath;
        const jsonFilePath = filePath.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json');
        // 读取当前文件的内容
        const documentText = editor.document.getText();
        // 检查并初始化 JSON 文件
        if (!fs.existsSync(jsonFilePath)) {
          await initializeJsonFile(jsonFilePath, documentText);
        }
        const lines = documentText.split('\n');

        // Define a decoration type with red color and transparency
        const decorationType = vscode.window.createTextEditorDecorationType({
          backgroundColor: 'rgba(0, 0, 255, 0.3)',
        });

        // Apply the decoration to the selected text
        editor.setDecorations(decorationType, [selection]);

        // 获取选中区域的起始和结束行
        const startLine = selection.start.line;
        const endLine = selection.end.line;

        // 读取现有的 JSON 数据
        let jsonData = [];
        const jsonContent = fs.readFileSync(jsonFilePath, 'utf-8');
        jsonData = JSON.parse(jsonContent);

        // 创建要装饰的范围数组
        const rangesToDecorate = [];

        // 遍历选中的每一行
        for (let lineNumber = startLine; lineNumber <= endLine; lineNumber++) {
          const selectedLineContent = lines[lineNumber];

          // 查找当前行在 JSON 中是否已经存在
          const lineEntry = jsonData.find((entry: any) => entry.content === selectedLineContent);

          if (lineEntry) {
            lineEntry.type = 3;
          } else {
            // 如果行不存在，添加一个新的记录
            jsonData.push({
              type: 3,
              content: selectedLineContent,
            });
          }

          // 为选定行创建范围
          const range = new vscode.Range(lineNumber, 0, lineNumber, lines[lineNumber].length);
          rangesToDecorate.push(range);
        }

        // 将更新后的 JSON 数据写回文件
        fs.writeFileSync(jsonFilePath, JSON.stringify(jsonData, null, 2), 'utf-8');
        vscode.window.showInformationMessage('Style changes saved to JSON file successfully!');
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.changeColorGreen', async () => {
      await (async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No editor is active');
          return;
        }

        const selection = editor.selection;
        if (selection.isEmpty) {
          vscode.window.showInformationMessage('No text selected');
          return;
        }
        // 获取当前文件路径
        const filePath = editor.document.uri.fsPath;
        const jsonFilePath = filePath.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json');
        // 读取当前文件的内容
        const documentText = editor.document.getText();
        // 检查并初始化 JSON 文件
        if (!fs.existsSync(jsonFilePath)) {
          await initializeJsonFile(jsonFilePath, documentText);
        }
        const lines = documentText.split('\n');

        // Define a decoration type with red color and transparency
        const decorationType = vscode.window.createTextEditorDecorationType({
          backgroundColor: 'rgba(0, 255, 0, 0.3)',
        });

        // Apply the decoration to the selected text
        editor.setDecorations(decorationType, [selection]);

        // 获取选中区域的起始和结束行
        const startLine = selection.start.line;
        const endLine = selection.end.line;

        // 读取现有的 JSON 数据
        let jsonData = [];
        const jsonContent = fs.readFileSync(jsonFilePath, 'utf-8');
        jsonData = JSON.parse(jsonContent);

        // 创建要装饰的范围数组
        const rangesToDecorate = [];

        // 遍历选中的每一行
        for (let lineNumber = startLine; lineNumber <= endLine; lineNumber++) {
          const selectedLineContent = lines[lineNumber];

          // 查找当前行在 JSON 中是否已经存在
          const lineEntry = jsonData.find((entry: any) => entry.content === selectedLineContent);

          if (lineEntry) {
            lineEntry.type = 4;
          } else {
            // 如果行不存在，添加一个新的记录
            jsonData.push({
              type: 4,
              content: selectedLineContent,
            });
          }

          // 为选定行创建范围
          const range = new vscode.Range(lineNumber, 0, lineNumber, lines[lineNumber].length);
          rangesToDecorate.push(range);
        }

        // 将更新后的 JSON 数据写回文件
        fs.writeFileSync(jsonFilePath, JSON.stringify(jsonData, null, 2), 'utf-8');
        vscode.window.showInformationMessage('Style changes saved to JSON file successfully!');
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.changeColorPurple', async () => {
      await (async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No editor is active');
          return;
        }

        const selection = editor.selection;
        if (selection.isEmpty) {
          vscode.window.showInformationMessage('No text selected');
          return;
        }
        // 获取当前文件路径
        const filePath = editor.document.uri.fsPath;
        const jsonFilePath = filePath.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json');
        // 读取当前文件的内容
        const documentText = editor.document.getText();
        // 检查并初始化 JSON 文件
        if (!fs.existsSync(jsonFilePath)) {
          await initializeJsonFile(jsonFilePath, documentText);
        }
        const lines = documentText.split('\n');

        // Define a decoration type with red color and transparency
        const decorationType = vscode.window.createTextEditorDecorationType({
          backgroundColor: 'rgba(128, 0, 128, 0.3)',
        });

        // Apply the decoration to the selected text
        editor.setDecorations(decorationType, [selection]);

        // 获取选中区域的起始和结束行
        const startLine = selection.start.line;
        const endLine = selection.end.line;

        // 读取现有的 JSON 数据
        let jsonData = [];
        const jsonContent = fs.readFileSync(jsonFilePath, 'utf-8');
        jsonData = JSON.parse(jsonContent);

        // 创建要装饰的范围数组
        const rangesToDecorate = [];

        // 遍历选中的每一行
        for (let lineNumber = startLine; lineNumber <= endLine; lineNumber++) {
          const selectedLineContent = lines[lineNumber];

          // 查找当前行在 JSON 中是否已经存在
          const lineEntry = jsonData.find((entry: any) => entry.content === selectedLineContent);

          if (lineEntry) {
            lineEntry.type = 5;
          } else {
            // 如果行不存在，添加一个新的记录
            jsonData.push({
              type: 5,
              content: selectedLineContent,
            });
          }

          // 为选定行创建范围
          const range = new vscode.Range(lineNumber, 0, lineNumber, lines[lineNumber].length);
          rangesToDecorate.push(range);
        }

        // 将更新后的 JSON 数据写回文件
        fs.writeFileSync(jsonFilePath, JSON.stringify(jsonData, null, 2), 'utf-8');
        vscode.window.showInformationMessage('Style changes saved to JSON file successfully!');
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.submitColorRed', () => {
      (async () => {
        webviewViewProvider?.disable();
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No active editor!');
          webviewViewProvider?.able();
          return;
        }
        const document = editor.document;
        const language = vscode.workspace.getConfiguration('ai').get('language') + "";
        const fileExtension: string = getFileExtension(language);
        const fileName = document.fileName;
        const fileType1 = fileName.substring(fileName.lastIndexOf('\\') + 1);
        const filename1 = fileType1.substring(0, fileType1.lastIndexOf('.'));
        let project = projects.find(project => (project.segments.find(segment => segment.name.replace(/:/g, '-') === filename1)));
        let result = "";
        let res = "";
        let currentCode = "";
        // 文件路径
        const filename = fileName.substring(0, fileName.lastIndexOf('.')) + `${fileExtension}`;
        // 检查文件是否存在
        if (fs.existsSync(filename)) {
          currentCode = fs.readFileSync(filename, 'utf8');
          if (currentCode === "还未生成java代码") { currentCode = ""; }
          console.log(`File ${filename} exists. Reading currentCode from ${filename}，${currentCode}`)
        } else {
          console.log(`File ${filename} does not exist. Proceeding without current code "${filename}".`);
        }
        const codeTypeFile = fileName.substring(0, fileName.lastIndexOf('.')) + '_txt.json';
        const content = extractByTypeFromFile(codeTypeFile, 2);
        let codeType = "";
        if (fs.existsSync(codeTypeFile)) {
          codeType = fs.readFileSync(codeTypeFile, 'utf8');
          console.log(`File ${codeTypeFile} exists. Reading currentCode from ${codeTypeFile}`);
        }
        if (project && currentCode.length < 1) {
          result = await askAI(content + `上面的内容是你之前帮我生成一个模块中的部分伪代码，结合整个项目的需求，书写这些伪代码对应的代码。注意，你只需要生成代码，不需要考虑其他模块，并请根据上面的伪代码，生成他的${fileExtension}代码。不用给我代码
                    此外，这是我的伪代码样式结构体：${codeType}。若为空，请忽略。请在生成代码后，过滤掉空行，以代码行为单位，给出代码和对应的type信息。示例如下：
                    1（应为number，对应:currentCode中，产生该代码的伪代码对应的type值。每行代码都需要对应某一行伪代码，可以多行代码对应一行伪代码。）
                    import os;（对应本行代码的内容）
                    你只需给出`+ content + `对应部分的代码和type信息，不要出现任何其他内容，包括注释。`, project.id);
          let structuredResult: CodeLine[] = [];
          try {
            let structured = parseCodeToStructure(result, filename);
            structuredResult = structured;
          }
          catch (error) {
            console.error(`转换为json格式时出错: ` + error);
          }
          try {
            fs.writeFileSync(filename.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json'), JSON.stringify(structuredResult, null, 2), 'utf-8');
          }
          catch (error) {
            console.error(`创建json文件时出错: ` + error);
            webviewViewProvider?.able();
            structuredResult = [];
          }
          if (structuredResult.length > 0) {
            res = structuredResult
              .filter((item: { content: string }) => item.content.trim() !== '') // 过滤掉空的 content
              .map((item: { content: string }) => item.content) // 提取 content
              .join('\n'); // 用 \n 连接每行内容
            try {
              fs.writeFileSync(filename, res);
            } catch (error) {
              console.error(`创建文件"${filename}"时出错: ` + error);
            }
          }
        }
        else if (project && currentCode.length > 0) {
          result = await askAI(content + `上面的内容是你之前帮我生成一个模块中的部分伪代码，结合整个项目的需求和我已有的代码` + currentCode + `，在已有代码的基础上书写这些伪代码对应的代码。注意，你只需要生成代码，不需要考虑其他模块，并请根据上面的伪代码，生成他的${fileExtension}代码。不用给我代码
                    此外，这是我的伪代码样式结构体：${codeType}。若为空，请忽略。请在生成代码后，过滤掉空行，以代码行为单位，给出代码和对应的type信息。示例如下：
                    1（应为number，对应:currentCode中，产生该代码的伪代码对应的type值。每行代码都需要对应某一行伪代码，可以多行代码对应一行伪代码。）
                    import os;（对应本行代码的内容）
                    你只需给出代码和对应的type信息，不要出现任何其他内容，包括注释。`, project.id);
          const structuredResult = parseCodeToStructure(result, filename);
          try {
            fs.writeFileSync(filename.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json'), JSON.stringify(structuredResult, null, 2), 'utf-8');
          }
          catch (error) {
            console.error(`创建json文件时出错: ` + error);
            webviewViewProvider?.able();
          }
          // 遍历数组并提取 content 字段
          res = structuredResult
            .filter((item: { content: string }) => item.content.trim() !== '') // 过滤掉空的 content
            .map((item: { content: string }) => item.content) // 提取 content
            .join('\n'); // 用 \n 连接每行内容
          try {
            fs.writeFileSync(filename, res);
          } catch (error) {
            console.error(`创建文件"${filename}"时出错: ` + error);
          }
        }
        console.log("代码生成完毕并保存，请继续操作");
        webviewViewProvider?.able();
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.submitColorBlue', () => {
      (async () => {
        webviewViewProvider?.disable();
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No active editor!');
          webviewViewProvider?.able();
          return;
        }
        const document = editor.document;
        const language = vscode.workspace.getConfiguration('ai').get('language') + "";
        const fileExtension: string = getFileExtension(language);
        const fileName = document.fileName;
        const fileType1 = fileName.substring(fileName.lastIndexOf('\\') + 1);
        const filename1 = fileType1.substring(0, fileType1.lastIndexOf('.'));
        let project = projects.find(project => (project.segments.find(segment => segment.name.replace(/:/g, '-') === filename1)));
        let result = "";
        let res = "";
        let currentCode = "";
        // 文件路径
        const filename = fileName.substring(0, fileName.lastIndexOf('.')) + `${fileExtension}`;
        // 检查文件是否存在
        if (fs.existsSync(filename)) {
          currentCode = fs.readFileSync(filename, 'utf8');
          if (currentCode === "还未生成java代码") { currentCode = ""; }
          console.log(`File ${filename} exists. Reading currentCode from ${filename}，${currentCode}`)
        } else {
          console.log(`File ${filename} does not exist. Proceeding without current code "${filename}".`);
        }
        const codeTypeFile = fileName.substring(0, fileName.lastIndexOf('.')) + '_txt.json';
        const content = extractByTypeFromFile(codeTypeFile, 4);
        let codeType = "";
        if (fs.existsSync(codeTypeFile)) {
          codeType = fs.readFileSync(codeTypeFile, 'utf8');
          console.log(`File ${codeTypeFile} exists. Reading currentCode from ${codeTypeFile}`);
        }
        if (project && currentCode.length < 1) {
          result = await askAI(content + `上面的内容是你之前帮我生成一个模块中的部分伪代码，结合整个项目的需求，书写这些伪代码对应的代码。注意，你只需要生成代码，不需要考虑其他模块，并请根据上面的伪代码，生成他的${fileExtension}代码。不用给我代码
                  此外，这是我的伪代码样式结构体：${codeType}。若为空，请忽略。请在生成代码后，过滤掉空行，以代码行为单位，给出代码和对应的type信息。示例如下：
                  1（应为number，对应:currentCode中，产生该代码的伪代码对应的type值。每行代码都需要对应某一行伪代码，可以多行代码对应一行伪代码。）
                  import os;（对应本行代码的内容）
                  你只需给出代码和对应的type信息，不要出现任何其他内容，包括注释。`, project.id);
          let structuredResult: CodeLine[] = [];
          try {
            let structured = parseCodeToStructure(result, filename);
            structuredResult = structured;
          }
          catch (error) {
            console.error(`转换为json格式时出错: ` + error);
          }
          try {
            fs.writeFileSync(filename.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json'), JSON.stringify(structuredResult, null, 2), 'utf-8');
          }
          catch (error) {
            console.error(`创建json文件时出错: ` + error);
            webviewViewProvider?.able();
            structuredResult = [];
          }
          if (structuredResult.length > 0) {
            res = structuredResult
              .filter((item: { content: string }) => item.content.trim() !== '') // 过滤掉空的 content
              .map((item: { content: string }) => item.content) // 提取 content
              .join('\n'); // 用 \n 连接每行内容
            try {
              fs.writeFileSync(filename, res);
            } catch (error) {
              console.error(`创建文件"${filename}"时出错: ` + error);
            }
          }
        }
        else if (project && currentCode.length > 0) {
          result = await askAI(content + `上面的内容是你之前帮我生成一个模块中的部分伪代码，结合整个项目的需求和我已有的代码` + currentCode + `，在已有代码的基础上书写这些伪代码对应的代码。注意，你只需要生成代码，不需要考虑其他模块，并请根据上面的伪代码，生成他的${fileExtension}代码。不用给我代码
                  此外，这是我的伪代码样式结构体：${codeType}。若为空，请忽略。请在生成代码后，过滤掉空行，以代码行为单位，给出代码和对应的type信息。示例如下：
                  1（应为number，对应:currentCode中，产生该代码的伪代码对应的type值。每行代码都需要对应某一行伪代码，可以多行代码对应一行伪代码。）
                  import os;（对应本行代码的内容）
                  你只需给出代码和对应的type信息，不要出现任何其他内容，包括注释。`, project.id);
          const structuredResult = parseCodeToStructure(result, filename);
          try {
            fs.writeFileSync(filename.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json'), JSON.stringify(structuredResult, null, 2), 'utf-8');
          }
          catch (error) {
            console.error(`创建json文件时出错: ` + error);
            webviewViewProvider?.able();
          }
          // 遍历数组并提取 content 字段
          res = structuredResult
            .filter((item: { content: string }) => item.content.trim() !== '') // 过滤掉空的 content
            .map((item: { content: string }) => item.content) // 提取 content
            .join('\n'); // 用 \n 连接每行内容
          try {
            fs.writeFileSync(filename, res);
          } catch (error) {
            console.error(`创建文件"${filename}"时出错: ` + error);
            webviewViewProvider?.able();
          }
        }
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.submitColorGreen', () => {
      (async () => {
        webviewViewProvider?.disable();
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No active editor!');
          webviewViewProvider?.able();
          return;
        }
        const document = editor.document;
        const language = vscode.workspace.getConfiguration('ai').get('language') + "";
        const fileExtension: string = getFileExtension(language);
        const fileName = document.fileName;
        const fileType1 = fileName.substring(fileName.lastIndexOf('\\') + 1);
        const filename1 = fileType1.substring(0, fileType1.lastIndexOf('.'));
        let project = projects.find(project => (project.segments.find(segment => segment.name.replace(/:/g, '-') === filename1)));
        let result = "";
        let res = "";
        let currentCode = "";
        // 文件路径
        const filename = fileName.substring(0, fileName.lastIndexOf('.')) + `${fileExtension}`;
        // 检查文件是否存在
        if (fs.existsSync(filename)) {
          currentCode = fs.readFileSync(filename, 'utf8');
          if (currentCode === "还未生成java代码") { currentCode = ""; }
          console.log(`File ${filename} exists. Reading currentCode from ${filename}，${currentCode}`)
        } else {
          console.log(`File ${filename} does not exist. Proceeding without current code "${filename}".`);
        }
        const codeTypeFile = fileName.substring(0, fileName.lastIndexOf('.')) + '_txt.json';
        const content = extractByTypeFromFile(codeTypeFile, 3);
        let codeType = "";
        if (fs.existsSync(codeTypeFile)) {
          codeType = fs.readFileSync(codeTypeFile, 'utf8');
          console.log(`File ${codeTypeFile} exists. Reading currentCode from ${codeTypeFile}`);
        }
        if (project && currentCode.length < 1) {
          result = await askAI(content + `上面的内容是你之前帮我生成一个模块中的部分伪代码，结合整个项目的需求，书写这些伪代码对应的代码。注意，你只需要生成代码，不需要考虑其他模块，并请根据上面的伪代码，生成他的${fileExtension}代码。不用给我代码
                  此外，这是我的伪代码样式结构体：${codeType}。若为空，请忽略。请在生成代码后，过滤掉空行，以代码行为单位，给出代码和对应的type信息。示例如下：
                  1（应为number，对应:currentCode中，产生该代码的伪代码对应的type值。每行代码都需要对应某一行伪代码，可以多行代码对应一行伪代码。）
                  import os;（对应本行代码的内容）
                  你只需给出代码和对应的type信息，不要出现任何其他内容，包括注释。`, project.id);
          let structuredResult: CodeLine[] = [];
          try {
            let structured = parseCodeToStructure(result, filename);
            structuredResult = structured;
          }
          catch (error) {
            console.error(`转换为json格式时出错: ` + error);
          }
          try {
            fs.writeFileSync(filename.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json'), JSON.stringify(structuredResult, null, 2), 'utf-8');
          }
          catch (error) {
            console.error(`创建json文件时出错: ` + error);
            webviewViewProvider?.able();
            structuredResult = [];
          }
          if (structuredResult.length > 0) {
            res = structuredResult
              .filter((item: { content: string }) => item.content.trim() !== '') // 过滤掉空的 content
              .map((item: { content: string }) => item.content) // 提取 content
              .join('\n'); // 用 \n 连接每行内容
            try {
              fs.writeFileSync(filename, res);
            } catch (error) {
              console.error(`创建文件"${filename}"时出错: ` + error);
            }
          }
        }
        else if (project && currentCode.length > 0) {
          result = await askAI(content + `上面的内容是你之前帮我生成一个模块中的部分伪代码，结合整个项目的需求和我已有的代码` + currentCode + `，在已有代码的基础上书写这些伪代码对应的代码。注意，你只需要生成代码，不需要考虑其他模块，并请根据上面的伪代码，生成他的${fileExtension}代码。不用给我代码
                  此外，这是我的伪代码样式结构体：${codeType}。若为空，请忽略。请在生成代码后，过滤掉空行，以代码行为单位，给出代码和对应的type信息。示例如下：
                  1（应为number，对应:currentCode中，产生该代码的伪代码对应的type值。每行代码都需要对应某一行伪代码，可以多行代码对应一行伪代码。）
                  import os;（对应本行代码的内容）
                  你只需给出代码和对应的type信息，不要出现任何其他内容，包括注释。`, project.id);
          const structuredResult = parseCodeToStructure(result, filename);
          try {
            fs.writeFileSync(filename.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json'), JSON.stringify(structuredResult, null, 2), 'utf-8');
          }
          catch (error) {
            console.error(`创建json文件时出错: ` + error);
            webviewViewProvider?.able();
          }
          // 遍历数组并提取 content 字段
          res = structuredResult
            .filter((item: { content: string }) => item.content.trim() !== '') // 过滤掉空的 content
            .map((item: { content: string }) => item.content) // 提取 content
            .join('\n'); // 用 \n 连接每行内容
          try {
            fs.writeFileSync(filename, res);
          } catch (error) {
            console.error(`创建文件"${filename}"时出错: ` + error);
            webviewViewProvider?.able();
          }
        }
      })();
    }),
    vscode.commands.registerCommand('CodeToolBox.submitColorPurple', () => {
      (async () => {
        webviewViewProvider?.disable();
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
          vscode.window.showInformationMessage('No active editor!');
          webviewViewProvider?.able();
          return;
        }
        const document = editor.document;
        const language = vscode.workspace.getConfiguration('ai').get('language') + "";
        const fileExtension: string = getFileExtension(language);
        const fileName = document.fileName;
        const fileType1 = fileName.substring(fileName.lastIndexOf('\\') + 1);
        const filename1 = fileType1.substring(0, fileType1.lastIndexOf('.'));
        let project = projects.find(project => (project.segments.find(segment => segment.name.replace(/:/g, '-') === filename1)));
        let result = "";
        let res = "";
        let currentCode = "";
        // 文件路径
        const filename = fileName.substring(0, fileName.lastIndexOf('.')) + `${fileExtension}`;
        // 检查文件是否存在
        if (fs.existsSync(filename)) {
          currentCode = fs.readFileSync(filename, 'utf8');
          if (currentCode === "还未生成java代码") { currentCode = ""; }
          console.log(`File ${filename} exists. Reading currentCode from ${filename}，${currentCode}`)
        } else {
          console.log(`File ${filename} does not exist. Proceeding without current code "${filename}".`);
        }
        const codeTypeFile = fileName.substring(0, fileName.lastIndexOf('.')) + '_txt.json';
        const content = extractByTypeFromFile(codeTypeFile, 5);
        let codeType = "";
        if (fs.existsSync(codeTypeFile)) {
          codeType = fs.readFileSync(codeTypeFile, 'utf8');
          console.log(`File ${codeTypeFile} exists. Reading currentCode from ${codeTypeFile}`);
        }
        if (project && currentCode.length < 1) {
          result = await askAI(content + `上面的内容是你之前帮我生成一个模块中的部分伪代码，结合整个项目的需求，书写这些伪代码对应的代码。注意，你只需要生成代码，不需要考虑其他模块，并请根据上面的伪代码，生成他的${fileExtension}代码。不用给我代码
                  此外，这是我的伪代码样式结构体：${codeType}。若为空，请忽略。请在生成代码后，过滤掉空行，以代码行为单位，给出代码和对应的type信息。示例如下：
                  1（应为number，对应:currentCode中，产生该代码的伪代码对应的type值。每行代码都需要对应某一行伪代码，可以多行代码对应一行伪代码。）
                  import os;（对应本行代码的内容）
                  你只需给出代码和对应的type信息，不要出现任何其他内容，包括注释。`, project.id);
          let structuredResult: CodeLine[] = [];
          try {
            let structured = parseCodeToStructure(result, filename);
            structuredResult = structured;
          }
          catch (error) {
            console.error(`转换为json格式时出错: ` + error);
          }
          try {
            fs.writeFileSync(filename.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json'), JSON.stringify(structuredResult, null, 2), 'utf-8');
          }
          catch (error) {
            console.error(`创建json文件时出错: ` + error);
            webviewViewProvider?.able();
            structuredResult = [];
          }
          if (structuredResult.length > 0) {
            res = structuredResult
              .filter((item: { content: string }) => item.content.trim() !== '') // 过滤掉空的 content
              .map((item: { content: string }) => item.content) // 提取 content
              .join('\n'); // 用 \n 连接每行内容
            try {
              fs.writeFileSync(filename, res);
            } catch (error) {
              console.error(`创建文件"${filename}"时出错: ` + error);
            }
          }
        }
        else if (project && currentCode.length > 0) {
          result = await askAI(content + `上面的内容是你之前帮我生成一个模块中的部分伪代码，结合整个项目的需求和我已有的代码` + currentCode + `，在已有代码的基础上书写这些伪代码对应的代码。注意，你只需要生成代码，不需要考虑其他模块，并请根据上面的伪代码，生成他的${fileExtension}代码。不用给我代码
                  此外，这是我的伪代码样式结构体：${codeType}。若为空，请忽略。请在生成代码后，过滤掉空行，以代码行为单位，给出代码和对应的type信息。示例如下：
                  1（应为number，对应:currentCode中，产生该代码的伪代码对应的type值。每行代码都需要对应某一行伪代码，可以多行代码对应一行伪代码。）
                  import os;（对应本行代码的内容）
                  你只需给出代码和对应的type信息，不要出现任何其他内容，包括注释。`, project.id);
          const structuredResult = parseCodeToStructure(result, filename);
          try {
            fs.writeFileSync(filename.replace(/\.java$/, '_java.json').replace(/\.txt$/, '_txt.json'), JSON.stringify(structuredResult, null, 2), 'utf-8');
          }
          catch (error) {
            console.error(`创建json文件时出错: ` + error);
            webviewViewProvider?.able();
          }
          // 遍历数组并提取 content 字段
          res = structuredResult
            .filter((item: { content: string }) => item.content.trim() !== '') // 过滤掉空的 content
            .map((item: { content: string }) => item.content) // 提取 content
            .join('\n'); // 用 \n 连接每行内容
          try {
            fs.writeFileSync(filename, res);
          } catch (error) {
            console.error(`创建文件"${filename}"时出错: ` + error);
            webviewViewProvider?.able();
          }
        }
      })();
    })
  )
  interface FileData {
    name: string;
    content: string;
  }

}
